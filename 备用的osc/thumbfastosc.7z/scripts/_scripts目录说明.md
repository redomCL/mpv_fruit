# file_browser
* 文件浏览脚本，来源：https://github.com/dyphire/mpv-config

# adevice-list.lua
* 音频设备菜单脚本，来源：https://github.com/dyphire/mpv-config

# chapter-list.lua
* 章节菜单脚本，来源：https://github.com/dyphire/mpv-config

# dialog.lua、dyn_menu.lua、menu.dll
* 播放器菜单，来源：https://github.com/tsl0922/mpv-menu-plugin

# load_plus.lua
* 同类文件加载脚本，来源：https://github.com/hooke007/MPV_lazy

# playlistmanager.lua
* 高级播放列表脚本，来源：https://github.com/dyphire/mpv-config

# stats_chs.lua
* 解码简要汉化脚本，来源：https://github.com/hooke007/MPV_lazy

# thumbfast.lua
* 预览图脚本，来源：https://github.com/dyphire/mpv-config

# thumbfastosc.lua
* thumbfastosc自定义osc脚本，来源：https://github.com/po5/thumbfast

# track-list.lua
* 轨道菜单脚本，来源：https://github.com/dyphire/mpv-config

# uosc.lua
* uosc自定义osc脚本，来源：https://github.com/tomasklaen/uosc，参照：https://github.com/dyphire/mpv-config