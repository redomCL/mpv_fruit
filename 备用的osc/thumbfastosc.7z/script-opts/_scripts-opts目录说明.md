# adevice-list.conf
* 音频设备菜单脚本配置文件

# chapter-list.conf
* 章节菜单脚本配置文件

# file_browser.conf
* 文件浏览脚本配置文件

# load_plus.conf
* 同类文件加载脚本配置文件

# osc.conf
* 内置默认osc脚本配置文件

# playlistmanager.conf
* 高级播放列表脚本配置文件

# stats_chs.conf
* 解码简要汉化脚本配置文件

# thumbfast.conf
* 预览图脚本配置文件

# osc.conf
* thumbfastosc自定义osc脚本配置文件

# track-list.conf
* 轨道菜单脚本配置文件